/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imovel;
/**
 *
 * @author otavi
 */
public class Imovel {

   
    enum Categorias {comercial, residencial};
    enum Tipos {Apartamento,Casa,Chacara,Sala,Salão,Sítio}; 
    public Categorias categoria;
    public Tipos tipo;
    private String nome;
    private String Descricao;
    private Double valorVenda;

    public Imovel(String nome, String Descricao,Categorias categoria, Tipos tipo, Double valorVenda) {
        this.nome = nome;
        this.Descricao = Descricao;
        this.valorVenda = valorVenda;
        this.categoria = categoria;
        this.tipo = tipo;
        
    }
   
 
    public Categorias getCategoria() {
        return categoria;
    }

    public Tipos getTipo() {
        return tipo;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    public Double getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }
    
    public String getValorString(){
        return this.valorVenda.toString();
    }
}
